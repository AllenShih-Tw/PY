thislist = ["apple", "banana", "cherry"]
print(thislist[-2])

thislist1 = ["apple", "banana", "cherry", "orange", "kiwi", "melon", "mango"]
print(thislist1[2:5])

thislist = ["apple", "banana", "cherry"]
thislist[1] = "blackcurrant"
print(thislist)

thislist = ["apple", "banana", "cherry"]
for x in thislist:
    print(x)

    thislist = ["apple", "banana", "cherry"]
if "a" in thislist:
    print("Yes, 'apple' is in the fruits list")
else:
    print("NO")
