import numpy
speed = [86,87,88,86,87,85,86]
x = numpy.std(speed)
print(x)

import numpy
speed = [32,111,138,28,59,77,97]
x = numpy.var(speed)
print(x)